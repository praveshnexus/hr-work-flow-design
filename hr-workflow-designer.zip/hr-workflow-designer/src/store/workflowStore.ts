import {
  addEdge,
  applyEdgeChanges,
  applyNodeChanges,
  type Connection,
  type Edge,
  type EdgeChange,
  type Node,
  type NodeChange,
} from '@xyflow/react'
import { create } from 'zustand'
import type { WorkflowNodeData } from '../types'

export type WorkflowNode = Node<WorkflowNodeData>
export type WorkflowEdge = Edge

interface Snapshot {
  nodes: WorkflowNode[]
  edges: WorkflowEdge[]
}

interface WorkflowStore {
  nodes: WorkflowNode[]
  edges: WorkflowEdge[]
  selectedNodeId: string | null

  // Undo/redo history
  past: Snapshot[]
  future: Snapshot[]

  // React Flow handlers
  onNodesChange: (changes: NodeChange[]) => void
  onEdgesChange: (changes: EdgeChange[]) => void
  onConnect: (connection: Connection) => void

  // Node actions
  addNode: (node: WorkflowNode) => void
  updateNodeData: (id: string, data: Partial<WorkflowNodeData>) => void
  deleteNode: (id: string) => void
  selectNode: (id: string | null) => void

  // Workflow actions
  clearWorkflow: () => void
  loadWorkflow: (nodes: WorkflowNode[], edges: WorkflowEdge[]) => void

  // History
  undo: () => void
  redo: () => void
  snapshot: () => void
}

let edgeCounter = 0

function saveSnapshot(state: WorkflowStore): Partial<WorkflowStore> {
  return {
    past: [
      ...state.past.slice(-30), // keep last 30 snapshots
      { nodes: state.nodes, edges: state.edges },
    ],
    future: [],
  }
}

export const useWorkflowStore = create<WorkflowStore>((set) => ({
  nodes: [],
  edges: [],
  selectedNodeId: null,
  past: [],
  future: [],

  onNodesChange: (changes) =>
    set((state) => ({
      nodes: applyNodeChanges(changes, state.nodes as Node[]) as WorkflowNode[],
    })),

  onEdgesChange: (changes) =>
    set((state) => ({
      edges: applyEdgeChanges(changes, state.edges),
    })),

  onConnect: (connection) =>
    set((state) => ({
      ...saveSnapshot(state),
      edges: addEdge(
        {
          ...connection,
          id: `edge-${++edgeCounter}`,
          animated: false,
          style: { stroke: '#94a3b8', strokeWidth: 1.5 },
        },
        state.edges
      ),
    })),

  addNode: (node) =>
    set((state) => ({
      ...saveSnapshot(state),
      nodes: [...state.nodes, node],
    })),

  updateNodeData: (id, data) =>
    set((state) => ({
      nodes: state.nodes.map((n) =>
        n.id === id
          ? { ...n, data: { ...n.data, ...data } as WorkflowNodeData }
          : n
      ),
    })),

  deleteNode: (id) =>
    set((state) => ({
      ...saveSnapshot(state),
      nodes: state.nodes.filter((n) => n.id !== id),
      edges: state.edges.filter((e) => e.source !== id && e.target !== id),
      selectedNodeId: state.selectedNodeId === id ? null : state.selectedNodeId,
    })),

  selectNode: (id) => set({ selectedNodeId: id }),

  clearWorkflow: () =>
    set((state) => ({
      ...saveSnapshot(state),
      nodes: [],
      edges: [],
      selectedNodeId: null,
    })),

  loadWorkflow: (nodes, edges) =>
    set((state) => ({
      ...saveSnapshot(state),
      nodes,
      edges,
      selectedNodeId: null,
    })),

  snapshot: () => set((state) => ({ ...saveSnapshot(state) })),

  undo: () =>
    set((state) => {
      if (state.past.length === 0) return {}
      const previous = state.past[state.past.length - 1]
      return {
        past: state.past.slice(0, -1),
        future: [{ nodes: state.nodes, edges: state.edges }, ...state.future.slice(0, 30)],
        nodes: previous.nodes,
        edges: previous.edges,
        selectedNodeId: null,
      }
    }),

  redo: () =>
    set((state) => {
      if (state.future.length === 0) return {}
      const next = state.future[0]
      return {
        past: [...state.past, { nodes: state.nodes, edges: state.edges }],
        future: state.future.slice(1),
        nodes: next.nodes,
        edges: next.edges,
        selectedNodeId: null,
      }
    }),
}))

export const useSelectedNode = () => {
  const nodes = useWorkflowStore((s) => s.nodes)
  const selectedNodeId = useWorkflowStore((s) => s.selectedNodeId)
  return nodes.find((n) => n.id === selectedNodeId) ?? null
}
