import type { NodeType } from '../types'

export interface NodeTypeConfig {
  type: NodeType
  label: string
  description: string
  color: string
  bgColor: string
  borderColor: string
  icon: string
}

export const NODE_TYPE_CONFIGS: Record<NodeType, NodeTypeConfig> = {
  start: {
    type: 'start',
    label: 'Start',
    description: 'Workflow entry point',
    color: '#185FA5',
    bgColor: '#E6F1FB',
    borderColor: '#378ADD',
    icon: '▶',
  },
  task: {
    type: 'task',
    label: 'Task',
    description: 'Human task step',
    color: '#3B6D11',
    bgColor: '#EAF3DE',
    borderColor: '#639922',
    icon: '☑',
  },
  approval: {
    type: 'approval',
    label: 'Approval',
    description: 'Manager approval step',
    color: '#854F0B',
    bgColor: '#FAEEDA',
    borderColor: '#BA7517',
    icon: '✓',
  },
  automated: {
    type: 'automated',
    label: 'Automated Step',
    description: 'System-triggered action',
    color: '#534AB7',
    bgColor: '#EEEDFE',
    borderColor: '#7F77DD',
    icon: '⚡',
  },
  end: {
    type: 'end',
    label: 'End',
    description: 'Workflow completion',
    color: '#993C1D',
    bgColor: '#FAECE7',
    borderColor: '#D85A30',
    icon: '■',
  },
}

export const getNodeConfig = (type: NodeType): NodeTypeConfig =>
  NODE_TYPE_CONFIGS[type]
