import { ReactFlowProvider } from '@xyflow/react'
import { WorkflowCanvas } from './components/canvas/WorkflowCanvas'
import { Sidebar } from './components/panels/Sidebar'
import { RightPanel } from './components/panels/RightPanel'

export default function App() {
  return (
    <ReactFlowProvider>
      <div className="flex h-screen w-screen overflow-hidden bg-gray-50">
        <Sidebar />
        <WorkflowCanvas />
        <RightPanel />
      </div>
    </ReactFlowProvider>
  )
}
