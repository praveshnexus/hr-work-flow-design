import type {
  AutomationAction,
  SimulateRequest,
  SimulateResponse,
  SimulateStepResult,
  NodeType,
} from '../types'

export const MOCK_AUTOMATIONS: AutomationAction[] = [
  { id: 'send_email', label: 'Send Email', params: ['to', 'subject', 'body'], description: 'Sends an automated email to the specified recipient' },
  { id: 'generate_doc', label: 'Generate Document', params: ['template', 'recipient'], description: 'Generates a document from a predefined template' },
  { id: 'notify_slack', label: 'Notify Slack', params: ['channel', 'message'], description: 'Posts a message to a Slack channel' },
  { id: 'update_hris', label: 'Update HRIS Record', params: ['employee_id', 'field', 'value'], description: 'Updates an employee record in the HRIS system' },
  { id: 'create_ticket', label: 'Create Ticket', params: ['title', 'assignee', 'priority'], description: 'Creates a task ticket in the project management tool' },
]

const delay = (ms: number) => new Promise((res) => setTimeout(res, ms))

export async function getAutomations(): Promise<AutomationAction[]> {
  await delay(200)
  return MOCK_AUTOMATIONS
}

export async function simulateWorkflow(request: SimulateRequest): Promise<SimulateResponse> {
  await delay(700)

  const errors: string[] = []
  const steps: SimulateStepResult[] = []
  const { nodes, edges } = request

  const startNodes = nodes.filter((n) => n.type === 'start')
  const endNodes = nodes.filter((n) => n.type === 'end')

  if (startNodes.length === 0) errors.push('Workflow must have a Start node')
  if (startNodes.length > 1) errors.push('Workflow can only have one Start node')
  if (endNodes.length === 0) errors.push('Workflow must have an End node')

  nodes.forEach((n) => {
    if (n.type !== 'start' && !edges.some((e) => e.target === n.id))
      errors.push(`Node "${n.data.title}" has no incoming connection`)
    if (n.type !== 'end' && !edges.some((e) => e.source === n.id))
      errors.push(`Node "${n.data.title}" has no outgoing connection`)
  })

  if (errors.length > 0) return { success: false, steps: [], errors, totalDurationMs: 0 }

  const startNode = startNodes[0]
  let currentId: string | undefined = startNode.id
  const visited = new Set<string>()
  let totalMs = 0
  const now = Date.now()

  while (currentId && !visited.has(currentId)) {
    visited.add(currentId)
    const node = nodes.find((n) => n.id === currentId)
    if (!node) break

    const durationMs = getSimDuration(node.type) + Math.floor(Math.random() * 200)
    totalMs += durationMs

    const step: SimulateStepResult = {
      nodeId: node.id,
      nodeType: node.type,
      title: String(node.data.title ?? ''),
      status: 'success',
      detail: getStepDetail(node.type, node.data as Record<string, unknown>),
      timestamp: new Date(now + totalMs).toISOString(),
      durationMs,
    }

    steps.push(step)

    if (node.type === 'approval' && Math.random() < 0.1) {
      step.status = 'error'
      step.detail = `Rejected by ${String(node.data.approverRole ?? 'approver')}`
      break
    }

    const nextEdge = edges.find((e) => e.source === currentId)
    currentId = nextEdge?.target
  }

  return { success: true, steps, errors: [], totalDurationMs: totalMs }
}

function getSimDuration(type: NodeType): number {
  return { start: 50, task: 1200, approval: 800, automated: 400, end: 100 }[type] ?? 200
}

function getStepDetail(type: NodeType, data: Record<string, unknown>): string {
  switch (type) {
    case 'start': return 'Workflow initiated'
    case 'task': return `Assigned to: ${String(data.assignee || 'Unassigned')}`
    case 'approval': return `Pending approval from ${String(data.approverRole || 'Manager')}`
    case 'automated': {
      const action = MOCK_AUTOMATIONS.find((a) => a.id === data.actionId)
      return `Executed: ${action?.label ?? 'Unknown action'}`
    }
    case 'end': return String(data.endMessage || 'Workflow completed')
    default: return ''
  }
}

export type { SimulateResponse }
