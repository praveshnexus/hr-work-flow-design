import { useCallback, useEffect, useState } from 'react'
import { useWorkflowStore } from '../store/workflowStore'
import type {
  NodeType,
  WorkflowNodeData,
  ValidationError,
  SerializedNode,
  SerializedEdge,
  WorkflowExport,
} from '../types'
import { simulateWorkflow } from '../api/mockApi'
import type { SimulateResponse } from '../api/mockApi'
import { nanoid } from '../lib/nanoid'

// ─── Default data per node type ──────────────────────────────────────
const DEFAULT_DATA: Record<NodeType, WorkflowNodeData> = {
  start: { nodeType: 'start', title: 'Start', metadata: [] },
  task: { nodeType: 'task', title: 'New Task', description: '', assignee: '', dueDate: '', customFields: [] },
  approval: { nodeType: 'approval', title: 'Approval', approverRole: 'Manager', autoApproveThreshold: 0 },
  automated: { nodeType: 'automated', title: 'Automated Step', actionId: 'send_email', actionParams: {} },
  end: { nodeType: 'end', title: 'End', endMessage: 'Workflow completed successfully', summaryFlag: false },
}

// ─── useNodeFactory ────────────────────────────────────────────────
export function useNodeFactory() {
  const addNode = useWorkflowStore((s) => s.addNode)

  const createNode = useCallback(
    (type: NodeType, position: { x: number; y: number }) => {
      const id = `${type}-${nanoid()}`
      addNode({ id, type, position, data: { ...DEFAULT_DATA[type] } })
      return id
    },
    [addNode]
  )

  return { createNode }
}

// ─── useWorkflowValidation ─────────────────────────────────────────
export function useWorkflowValidation() {
  const nodes = useWorkflowStore((s) => s.nodes)
  const edges = useWorkflowStore((s) => s.edges)

  const validate = useCallback((): ValidationError[] => {
    const errors: ValidationError[] = []
    const startNodes = nodes.filter((n) => n.type === 'start')
    const endNodes = nodes.filter((n) => n.type === 'end')

    if (nodes.length === 0) {
      errors.push({ message: 'Workflow is empty', severity: 'error' })
      return errors
    }
    if (startNodes.length === 0) errors.push({ message: 'Missing Start node', severity: 'error' })
    if (startNodes.length > 1) errors.push({ message: 'Only one Start node allowed', severity: 'error' })
    if (endNodes.length === 0) errors.push({ message: 'Missing End node', severity: 'error' })

    nodes.forEach((n) => {
      if (n.type !== 'start' && !edges.some((e) => e.target === n.id))
        errors.push({ nodeId: n.id, message: `"${n.data.title}" has no incoming connection`, severity: 'warning' })
      if (n.type !== 'end' && !edges.some((e) => e.source === n.id))
        errors.push({ nodeId: n.id, message: `"${n.data.title}" has no outgoing connection`, severity: 'warning' })
    })

    return errors
  }, [nodes, edges])

  // Set of node IDs with errors/warnings for canvas highlighting
  const getErrorNodeIds = useCallback((): Set<string> => {
    return new Set(validate().map((e) => e.nodeId).filter(Boolean) as string[])
  }, [validate])

  return { validate, getErrorNodeIds }
}

// ─── useSimulation ─────────────────────────────────────────────────
export function useSimulation() {
  const nodes = useWorkflowStore((s) => s.nodes)
  const edges = useWorkflowStore((s) => s.edges)
  const [result, setResult] = useState<SimulateResponse | null>(null)
  const [loading, setLoading] = useState(false)

  const run = useCallback(async () => {
    setLoading(true)
    const serializedNodes: SerializedNode[] = nodes.map((n) => ({
      id: n.id,
      type: n.type as NodeType,
      position: n.position,
      data: n.data,
    }))
    const serializedEdges: SerializedEdge[] = edges.map((e) => ({
      id: e.id,
      source: e.source,
      target: e.target,
    }))
    const res = await simulateWorkflow({ nodes: serializedNodes, edges: serializedEdges })
    setResult(res)
    setLoading(false)
    return res
  }, [nodes, edges])

  return { run, result, loading, reset: () => setResult(null) }
}

// ─── useWorkflowExport ─────────────────────────────────────────────
export function useWorkflowExport() {
  const nodes = useWorkflowStore((s) => s.nodes)
  const edges = useWorkflowStore((s) => s.edges)
  const loadWorkflow = useWorkflowStore((s) => s.loadWorkflow)

  const exportWorkflow = useCallback(() => {
    const data: WorkflowExport = {
      version: '1.0.0',
      name: 'HR Workflow',
      exportedAt: new Date().toISOString(),
      nodes: nodes.map((n) => ({ id: n.id, type: n.type as NodeType, position: n.position, data: n.data })),
      edges: edges.map((e) => ({ id: e.id, source: e.source, target: e.target })),
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'workflow.json'; a.click()
    URL.revokeObjectURL(url)
  }, [nodes, edges])

  const importWorkflow = useCallback((file: File) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data: WorkflowExport = JSON.parse(e.target?.result as string)
        const importedNodes = data.nodes.map((n) => ({
          id: n.id,
          type: n.type,
          position: n.position,
          data: n.data,
        }))
        const importedEdges = data.edges.map((e) => ({
          id: e.id,
          source: e.source,
          target: e.target,
          style: { stroke: '#94a3b8', strokeWidth: 1.5 },
        }))
        loadWorkflow(importedNodes, importedEdges)
      } catch {
        alert('Invalid workflow JSON file.')
      }
    }
    reader.readAsText(file)
  }, [loadWorkflow])

  return { exportWorkflow, importWorkflow }
}

// ─── useKeyboardShortcuts ──────────────────────────────────────────
export function useKeyboardShortcuts() {
  const undo = useWorkflowStore((s) => s.undo)
  const redo = useWorkflowStore((s) => s.redo)
  const selectedNodeId = useWorkflowStore((s) => s.selectedNodeId)
  const deleteNode = useWorkflowStore((s) => s.deleteNode)

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const isMac = navigator.platform.toUpperCase().includes('MAC')
      const ctrl = isMac ? e.metaKey : e.ctrlKey

      if (ctrl && e.key === 'z' && !e.shiftKey) { e.preventDefault(); undo() }
      if (ctrl && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) { e.preventDefault(); redo() }
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedNodeId) {
        const active = document.activeElement
        if (active?.tagName === 'INPUT' || active?.tagName === 'TEXTAREA') return
        deleteNode(selectedNodeId)
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [undo, redo, selectedNodeId, deleteNode])
}
