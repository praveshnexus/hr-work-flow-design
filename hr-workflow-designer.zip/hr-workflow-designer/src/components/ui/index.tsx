import { nanoid } from '../../lib/nanoid'
import type { KVPair } from '../../types'

// ─── FormField ───────────────────────────────────────────────────────

interface FormFieldProps {
  label: string
  required?: boolean
  children: React.ReactNode
}

export function FormField({ label, required, children }: FormFieldProps) {
  return (
    <div className="mb-4">
      <label className="block text-xs font-medium text-gray-500 mb-1.5">
        {label}
        {required && <span className="text-red-400 ml-0.5">*</span>}
      </label>
      {children}
    </div>
  )
}

// ─── Input ───────────────────────────────────────────────────────────

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {}

export function Input({ className = '', ...props }: InputProps) {
  return (
    <input
      className={`w-full px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm text-gray-800 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all placeholder:text-gray-300 ${className}`}
      {...props}
    />
  )
}

// ─── Textarea ────────────────────────────────────────────────────────

interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

export function Textarea({ className = '', ...props }: TextareaProps) {
  return (
    <textarea
      className={`w-full px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm text-gray-800 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all resize-none min-h-[72px] placeholder:text-gray-300 ${className}`}
      {...props}
    />
  )
}

// ─── Select ──────────────────────────────────────────────────────────

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  options: { value: string; label: string }[]
}

export function Select({ options, className = '', ...props }: SelectProps) {
  return (
    <select
      className={`w-full px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm text-gray-800 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all ${className}`}
      {...props}
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  )
}

// ─── Toggle ──────────────────────────────────────────────────────────

interface ToggleProps {
  checked: boolean
  onChange: (val: boolean) => void
  label: string
}

export function Toggle({ checked, onChange, label }: ToggleProps) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex items-center gap-3 text-sm text-gray-700 hover:text-gray-900 group"
    >
      <div
        className={`relative w-9 h-5 rounded-full transition-colors duration-200 ${
          checked ? 'bg-blue-500' : 'bg-gray-200'
        }`}
      >
        <div
          className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow-sm transition-transform duration-200 ${
            checked ? 'translate-x-4' : 'translate-x-0'
          }`}
        />
      </div>
      <span>{label}</span>
    </button>
  )
}

// ─── KVEditor ────────────────────────────────────────────────────────

interface KVEditorProps {
  pairs: KVPair[]
  onChange: (pairs: KVPair[]) => void
  keyPlaceholder?: string
  valuePlaceholder?: string
}

export function KVEditor({
  pairs,
  onChange,
  keyPlaceholder = 'key',
  valuePlaceholder = 'value',
}: KVEditorProps) {
  const add = () =>
    onChange([...pairs, { id: nanoid(), key: '', value: '' }])

  const remove = (id: string) =>
    onChange(pairs.filter((p) => p.id !== id))

  const update = (id: string, field: 'key' | 'value', val: string) =>
    onChange(pairs.map((p) => (p.id === id ? { ...p, [field]: val } : p)))

  return (
    <div>
      {pairs.length > 0 && (
        <div className="flex flex-col gap-1.5 mb-2">
          {pairs.map((pair) => (
            <div key={pair.id} className="flex gap-1.5">
              <input
                className="flex-1 min-w-0 px-2 py-1.5 rounded-md border border-gray-200 bg-white text-xs focus:outline-none focus:border-blue-400 text-gray-800 placeholder:text-gray-300"
                placeholder={keyPlaceholder}
                value={pair.key}
                onChange={(e) => update(pair.id, 'key', e.target.value)}
              />
              <input
                className="flex-1 min-w-0 px-2 py-1.5 rounded-md border border-gray-200 bg-white text-xs focus:outline-none focus:border-blue-400 text-gray-800 placeholder:text-gray-300"
                placeholder={valuePlaceholder}
                value={pair.value}
                onChange={(e) => update(pair.id, 'value', e.target.value)}
              />
              <button
                onClick={() => remove(pair.id)}
                className="w-7 h-7 flex items-center justify-center rounded-md border border-gray-200 text-gray-400 hover:bg-red-50 hover:text-red-500 hover:border-red-200 transition-colors text-sm flex-shrink-0"
              >
                ×
              </button>
            </div>
          ))}
        </div>
      )}
      <button
        onClick={add}
        className="text-xs text-blue-500 hover:text-blue-700 hover:underline flex items-center gap-1"
      >
        <span>+</span> Add field
      </button>
    </div>
  )
}

// ─── SectionTitle ────────────────────────────────────────────────────

export function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-[10px] font-semibold uppercase tracking-widest text-gray-400 mb-2 mt-4 first:mt-0">
      {children}
    </p>
  )
}

// ─── DeleteButton ────────────────────────────────────────────────────

interface DeleteButtonProps {
  onClick: () => void
  label?: string
}

export function DeleteButton({ onClick, label = 'Delete node' }: DeleteButtonProps) {
  return (
    <button
      onClick={onClick}
      className="w-full mt-4 py-2 rounded-lg border border-red-200 text-red-500 text-sm hover:bg-red-50 transition-colors"
    >
      {label}
    </button>
  )
}
