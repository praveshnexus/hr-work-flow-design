import type { NodeProps } from '@xyflow/react'
import { MOCK_AUTOMATIONS } from '../../api/mockApi'
import { useWorkflowValidation } from '../../hooks'
import type {
  ApprovalNodeData,
  AutomatedNodeData,
  EndNodeData,
  StartNodeData,
  TaskNodeData,
} from '../../types'
import { BaseNode } from './BaseNode'

function useHasError(id: string) {
  const { getErrorNodeIds } = useWorkflowValidation()
  return getErrorNodeIds().has(id)
}

export function StartNode({ id, data, selected }: NodeProps) {
  const d = data as unknown as StartNodeData
  const hasError = useHasError(id)
  const metaCount = d.metadata?.length ?? 0
  return <BaseNode id={id} data={d} selected={selected} hasError={hasError}
    subtitle={metaCount > 0 ? `${metaCount} metadata field${metaCount !== 1 ? 's' : ''}` : 'Entry point'}
    hideTargetHandle
  />
}

export function TaskNode({ id, data, selected }: NodeProps) {
  const d = data as unknown as TaskNodeData
  const hasError = useHasError(id)
  return <BaseNode id={id} data={d} selected={selected} hasError={hasError}
    subtitle={d.assignee ? `→ ${d.assignee}` : 'Unassigned'}
  />
}

export function ApprovalNode({ id, data, selected }: NodeProps) {
  const d = data as unknown as ApprovalNodeData
  const hasError = useHasError(id)
  return <BaseNode id={id} data={d} selected={selected} hasError={hasError}
    subtitle={`Approver: ${d.approverRole || 'Manager'}`}
  />
}

export function AutomatedNode({ id, data, selected }: NodeProps) {
  const d = data as unknown as AutomatedNodeData
  const hasError = useHasError(id)
  const action = MOCK_AUTOMATIONS.find((a) => a.id === d.actionId)
  return <BaseNode id={id} data={d} selected={selected} hasError={hasError}
    subtitle={action?.label ?? 'No action selected'}
  />
}

export function EndNode({ id, data, selected }: NodeProps) {
  const d = data as unknown as EndNodeData
  const hasError = useHasError(id)
  return <BaseNode id={id} data={d} selected={selected} hasError={hasError}
    subtitle={d.endMessage || 'Workflow complete'}
    hideSourceHandle
  />
}

export const nodeTypes = {
  start: StartNode,
  task: TaskNode,
  approval: ApprovalNode,
  automated: AutomatedNode,
  end: EndNode,
}
