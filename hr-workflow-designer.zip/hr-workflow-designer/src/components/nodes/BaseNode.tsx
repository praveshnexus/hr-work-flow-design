import { Handle, Position } from '@xyflow/react'
import { clsx } from 'clsx'
import { getNodeConfig } from '../../lib/nodeConfig'
import type { NodeType, WorkflowNodeData } from '../../types'
import { useWorkflowStore } from '../../store/workflowStore'

interface BaseNodeProps {
  id: string
  data: WorkflowNodeData
  selected?: boolean
  subtitle?: string
  hasError?: boolean
  hideSourceHandle?: boolean
  hideTargetHandle?: boolean
}

export function BaseNode({
  id,
  data,
  selected,
  subtitle,
  hasError,
  hideSourceHandle,
  hideTargetHandle,
}: BaseNodeProps) {
  const cfg = getNodeConfig(data.nodeType as NodeType)
  const selectNode = useWorkflowStore((s) => s.selectNode)

  return (
    <div
      onClick={() => selectNode(id)}
      className={clsx('relative min-w-[190px] max-w-[220px] rounded-xl border-2 transition-all duration-150 cursor-pointer select-none')}
      style={{
        backgroundColor: cfg.bgColor,
        borderColor: selected
          ? '#3b82f6'
          : hasError
          ? '#f87171'
          : cfg.borderColor,
        boxShadow: selected
          ? '0 0 0 3px rgba(59,130,246,0.18), 0 4px 12px rgba(0,0,0,0.08)'
          : hasError
          ? '0 0 0 3px rgba(248,113,113,0.18)'
          : '0 1px 4px rgba(0,0,0,0.06)',
      }}
    >
      {/* Error indicator */}
      {hasError && !selected && (
        <div className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-red-400 border-2 border-white flex items-center justify-center">
          <span className="text-white text-[8px] font-bold leading-none">!</span>
        </div>
      )}

      {/* Type badge */}
      <div className="flex items-center gap-1.5 px-3 pt-2.5 pb-0.5" style={{ color: cfg.color }}>
        <span className="text-[11px]">{cfg.icon}</span>
        <span className="text-[9px] font-bold uppercase tracking-widest opacity-75">{cfg.label}</span>
      </div>

      {/* Title */}
      <div className="px-3 pb-1">
        <p className="text-[13px] font-semibold text-gray-800 truncate leading-snug">
          {data.title || 'Untitled'}
        </p>
      </div>

      {/* Subtitle */}
      {subtitle && (
        <div className="px-3 pb-2.5">
          <p className="text-[11px] truncate opacity-75" style={{ color: cfg.color }}>
            {subtitle}
          </p>
        </div>
      )}

      {/* Handles */}
      {!hideTargetHandle && (
        <Handle type="target" position={Position.Left}
          style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: cfg.bgColor, border: `2px solid ${cfg.borderColor}` }}
        />
      )}
      {!hideSourceHandle && (
        <Handle type="source" position={Position.Right}
          style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: '#3b82f6', border: '2px solid #2563eb' }}
        />
      )}
    </div>
  )
}
