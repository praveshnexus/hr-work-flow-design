import { useState } from 'react'
import { clsx } from 'clsx'
import { useSelectedNode, useWorkflowStore } from '../../store/workflowStore'
import { useSimulation, useWorkflowValidation } from '../../hooks'
import { getNodeConfig } from '../../lib/nodeConfig'
import type { NodeType, SimulateStepResult, ValidationError } from '../../types'
import { ApprovalNodeForm, AutomatedNodeForm, EndNodeForm, StartNodeForm, TaskNodeForm } from './NodeForms'

type Tab = 'edit' | 'sandbox'

export function RightPanel() {
  const [activeTab, setActiveTab] = useState<Tab>('edit')
  const selectedNode = useSelectedNode()

  // Auto-switch to edit when a node is selected
  const handleTabClick = (tab: Tab) => setActiveTab(tab)

  return (
    <div className="w-[300px] flex-shrink-0 bg-white border-l border-gray-100 flex flex-col h-full overflow-hidden">
      <div className="flex border-b border-gray-100 flex-shrink-0">
        {(['edit', 'sandbox'] as Tab[]).map((tab) => (
          <button key={tab} onClick={() => handleTabClick(tab)}
            className={clsx(
              'flex-1 py-3 text-xs font-semibold transition-colors relative',
              activeTab === tab ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'
            )}
          >
            {tab === 'edit' ? (
              <span>Edit Node {selectedNode ? <span className="ml-1 px-1.5 py-0.5 rounded-full bg-blue-100 text-blue-600 text-[9px]">1</span> : ''}</span>
            ) : 'Sandbox'}
            {activeTab === tab && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500 rounded-t" />
            )}
          </button>
        ))}
      </div>

      <div className={clsx('flex-1 overflow-hidden flex flex-col', activeTab !== 'edit' && 'hidden')}>
        <EditPane />
      </div>
      <div className={clsx('flex-1 overflow-hidden flex flex-col', activeTab !== 'sandbox' && 'hidden')}>
        <SandboxPane />
      </div>
    </div>
  )
}

// ─── EditPane ──────────────────────────────────────────────────────
function EditPane() {
  const selectedNode = useSelectedNode()

  if (!selectedNode) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-3 p-6 text-center">
        <div className="w-12 h-12 rounded-2xl bg-gray-50 border border-gray-100 flex items-center justify-center text-2xl">✎</div>
        <div>
          <p className="text-sm font-medium text-gray-500">No node selected</p>
          <p className="text-xs text-gray-400 mt-1">Click any node on the canvas to edit its properties</p>
        </div>
      </div>
    )
  }

  const renderForm = () => {
    switch (selectedNode.type as NodeType) {
      case 'start':     return <StartNodeForm id={selectedNode.id} />
      case 'task':      return <TaskNodeForm id={selectedNode.id} />
      case 'approval':  return <ApprovalNodeForm id={selectedNode.id} />
      case 'automated': return <AutomatedNodeForm id={selectedNode.id} />
      case 'end':       return <EndNodeForm id={selectedNode.id} />
      default:          return null
    }
  }

  return <div className="flex-1 overflow-y-auto p-4">{renderForm()}</div>
}

// ─── SandboxPane ───────────────────────────────────────────────────
function SandboxPane() {
  const { validate } = useWorkflowValidation()
  const { run, result, loading, reset } = useSimulation()
  const nodes = useWorkflowStore((s) => s.nodes)
  const errors = validate()
  const hasErrors = errors.some((e: ValidationError) => e.severity === 'error')
  const canRun = !loading && !hasErrors && nodes.length > 0

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Validation panel */}
      <div className="p-4 border-b border-gray-50 flex-shrink-0">
        {errors.length > 0 ? (
          <div className="flex flex-col gap-1.5 mb-3">
            {errors.map((err: ValidationError, i: number) => (
              <div key={i} className={clsx(
                'flex items-start gap-2 px-3 py-2 rounded-lg text-xs',
                err.severity === 'error' ? 'bg-red-50 text-red-600' : 'bg-amber-50 text-amber-700'
              )}>
                <span className="mt-px">{err.severity === 'error' ? '⚠' : '!'}</span>
                <span>{err.message}</span>
              </div>
            ))}
          </div>
        ) : nodes.length > 0 ? (
          <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-green-50 text-green-700 text-xs mb-3">
            <span>✓</span><span>Workflow is valid — ready to simulate</span>
          </div>
        ) : null}

        <button
          onClick={canRun ? run : undefined}
          disabled={!canRun}
          className={clsx(
            'w-full py-2.5 rounded-xl text-sm font-semibold transition-all',
            canRun
              ? 'bg-blue-600 text-white hover:bg-blue-700 active:scale-[0.98] shadow-sm shadow-blue-200'
              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
          )}
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <span className="animate-spin inline-block w-3 h-3 border border-white border-t-transparent rounded-full" />
              Simulating...
            </span>
          ) : '▶  Run Simulation'}
        </button>
      </div>

      {/* Execution log */}
      <div className="flex-1 overflow-y-auto p-4">
        {!result && !loading && (
          <div className="flex flex-col items-center justify-center h-full gap-3 text-center">
            <div className="text-3xl opacity-20">⚙</div>
            <p className="text-xs text-gray-400">Run the simulation to see<br />a step-by-step execution log</p>
          </div>
        )}

        {result && (
          <>
            <div className="flex items-center justify-between mb-3">
              <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">
                Execution log
              </p>
              <button onClick={reset} className="text-[10px] text-gray-400 hover:text-gray-600">
                Clear
              </button>
            </div>

            {result.errors.length > 0 ? (
              <div className="space-y-1.5">
                {result.errors.map((e: string, i: number) => (
                  <div key={i} className="px-3 py-2 rounded-lg bg-red-50 text-red-600 text-xs flex gap-2">
                    <span>⚠</span><span>{e}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col gap-1">
                {result.steps.map((step: SimulateStepResult, i: number) => (
                  <SimStep key={i} step={step} index={i} total={result.steps.length} />
                ))}

                {/* Summary */}
                <div className="mt-3 p-3 rounded-xl bg-gray-50 border border-gray-100">
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span className="font-medium">Simulation complete</span>
                    <span className={result.steps.some(s => s.status === 'error') ? 'text-red-500' : 'text-green-600'}>
                      {result.steps.some(s => s.status === 'error') ? '✗ Failed' : '✓ Success'}
                    </span>
                  </div>
                  <div className="flex justify-between text-[11px] text-gray-400">
                    <span>{result.steps.length} steps</span>
                    <span>{result.totalDurationMs.toLocaleString()}ms total</span>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

// ─── SimStep ───────────────────────────────────────────────────────
function SimStep({ step, index, total }: { step: SimulateStepResult; index: number; total: number }) {
  const cfg = getNodeConfig(step.nodeType)
  const time = new Date(step.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  const isError = step.status === 'error'
  const isLast = index === total - 1

  return (
    <div className="flex gap-2.5">
      {/* Timeline line */}
      <div className="flex flex-col items-center flex-shrink-0">
        <div
          className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-semibold border-2 border-white shadow-sm"
          style={{ background: isError ? '#fca5a5' : cfg.bgColor, color: isError ? '#dc2626' : cfg.color }}
        >
          {isError ? '✕' : index + 1}
        </div>
        {!isLast && <div className="w-0.5 flex-1 bg-gray-100 my-0.5 min-h-[12px]" />}
      </div>

      {/* Content */}
      <div className={clsx('flex-1 min-w-0 pb-3', isLast && 'pb-0')}>
        <div className="flex items-start justify-between gap-1">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
              <span className="text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-md"
                style={{ background: cfg.bgColor, color: cfg.color }}>
                {cfg.label}
              </span>
              {isError && (
                <span className="text-[9px] font-bold text-red-500 uppercase">Failed</span>
              )}
            </div>
            <p className="text-xs font-semibold text-gray-700 truncate">{step.title}</p>
            <p className="text-[11px] text-gray-400 mt-0.5">{step.detail}</p>
          </div>
          <div className="flex flex-col items-end gap-0.5 flex-shrink-0">
            <span className="text-[10px] text-gray-300">{time}</span>
            <span className="text-[10px] text-gray-300">{step.durationMs}ms</span>
          </div>
        </div>
      </div>
    </div>
  )
}
