import { useEffect, useState } from 'react'
import { getAutomations, MOCK_AUTOMATIONS } from '../../api/mockApi'
import { useWorkflowStore } from '../../store/workflowStore'
import type {
  ApprovalNodeData,
  AutomatedNodeData,
  AutomationAction,
  EndNodeData,
  KVPair,
  StartNodeData,
  TaskNodeData,
} from '../../types'
import {
  DeleteButton,
  FormField,
  Input,
  KVEditor,
  SectionTitle,
  Select,
  Textarea,
  Toggle,
} from '../ui'

// ─── Shared header ───────────────────────────────────────────────────

function NodeFormHeader({
  icon,
  label,
  color,
  bg,
}: {
  icon: string
  label: string
  color: string
  bg: string
}) {
  return (
    <div
      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-semibold mb-4"
      style={{ background: bg, color }}
    >
      <span>{icon}</span>
      {label}
    </div>
  )
}

// ─── StartNodeForm ───────────────────────────────────────────────────

export function StartNodeForm({ id }: { id: string }) {
  const node = useWorkflowStore((s) => s.nodes.find((n) => n.id === id))
  const updateNodeData = useWorkflowStore((s) => s.updateNodeData)
  const deleteNode = useWorkflowStore((s) => s.deleteNode)
  if (!node) return null
  const data = node.data as StartNodeData

  return (
    <div>
      <NodeFormHeader icon="▶" label="Start Node" color="#185FA5" bg="#E6F1FB" />
      <FormField label="Title">
        <Input
          value={data.title}
          onChange={(e) => updateNodeData(id, { title: e.target.value })}
          placeholder="Workflow start title"
        />
      </FormField>
      <SectionTitle>Metadata</SectionTitle>
      <KVEditor
        pairs={data.metadata ?? []}
        onChange={(metadata) => updateNodeData(id, { metadata } as Partial<StartNodeData>)}
      />
      <DeleteButton onClick={() => deleteNode(id)} />
    </div>
  )
}

// ─── TaskNodeForm ────────────────────────────────────────────────────

export function TaskNodeForm({ id }: { id: string }) {
  const node = useWorkflowStore((s) => s.nodes.find((n) => n.id === id))
  const updateNodeData = useWorkflowStore((s) => s.updateNodeData)
  const deleteNode = useWorkflowStore((s) => s.deleteNode)
  if (!node) return null
  const data = node.data as TaskNodeData

  return (
    <div>
      <NodeFormHeader icon="☑" label="Task Node" color="#3B6D11" bg="#EAF3DE" />
      <FormField label="Title" required>
        <Input
          value={data.title}
          onChange={(e) => updateNodeData(id, { title: e.target.value })}
          placeholder="Task title"
        />
      </FormField>
      <FormField label="Description">
        <Textarea
          value={data.description}
          onChange={(e) => updateNodeData(id, { description: e.target.value })}
          placeholder="What needs to be done?"
        />
      </FormField>
      <FormField label="Assignee">
        <Input
          value={data.assignee}
          onChange={(e) => updateNodeData(id, { assignee: e.target.value })}
          placeholder="e.g. John Doe"
        />
      </FormField>
      <FormField label="Due date">
        <Input
          type="date"
          value={data.dueDate}
          onChange={(e) => updateNodeData(id, { dueDate: e.target.value })}
        />
      </FormField>
      <SectionTitle>Custom fields</SectionTitle>
      <KVEditor
        pairs={(data.customFields as KVPair[]) ?? []}
        onChange={(customFields) =>
          updateNodeData(id, { customFields } as Partial<TaskNodeData>)
        }
      />
      <DeleteButton onClick={() => deleteNode(id)} />
    </div>
  )
}

// ─── ApprovalNodeForm ─────────────────────────────────────────────────

const APPROVER_ROLES = ['Manager', 'HRBP', 'Director', 'VP', 'C-Level', 'Team Lead']

export function ApprovalNodeForm({ id }: { id: string }) {
  const node = useWorkflowStore((s) => s.nodes.find((n) => n.id === id))
  const updateNodeData = useWorkflowStore((s) => s.updateNodeData)
  const deleteNode = useWorkflowStore((s) => s.deleteNode)
  if (!node) return null
  const data = node.data as ApprovalNodeData

  return (
    <div>
      <NodeFormHeader icon="✓" label="Approval Node" color="#854F0B" bg="#FAEEDA" />
      <FormField label="Title">
        <Input
          value={data.title}
          onChange={(e) => updateNodeData(id, { title: e.target.value })}
          placeholder="Approval step title"
        />
      </FormField>
      <FormField label="Approver role">
        <Select
          value={data.approverRole}
          onChange={(e) => updateNodeData(id, { approverRole: e.target.value })}
          options={APPROVER_ROLES.map((r) => ({ value: r, label: r }))}
        />
      </FormField>
      <FormField label="Auto-approve threshold (days)">
        <Input
          type="number"
          min={0}
          value={data.autoApproveThreshold}
          onChange={(e) =>
            updateNodeData(id, { autoApproveThreshold: Number(e.target.value) })
          }
          placeholder="0 = manual only"
        />
      </FormField>
      <p className="text-xs text-gray-400 mt-1">
        If 0, approval is always manual. Any number N means auto-approve after N days with no response.
      </p>
      <DeleteButton onClick={() => deleteNode(id)} />
    </div>
  )
}

// ─── AutomatedNodeForm ────────────────────────────────────────────────

export function AutomatedNodeForm({ id }: { id: string }) {
  const node = useWorkflowStore((s) => s.nodes.find((n) => n.id === id))
  const updateNodeData = useWorkflowStore((s) => s.updateNodeData)
  const deleteNode = useWorkflowStore((s) => s.deleteNode)
  const [automations, setAutomations] = useState<AutomationAction[]>(MOCK_AUTOMATIONS)

  useEffect(() => {
    getAutomations().then(setAutomations)
  }, [])

  if (!node) return null
  const data = node.data as AutomatedNodeData
  const currentAction = automations.find((a) => a.id === data.actionId)

  return (
    <div>
      <NodeFormHeader icon="⚡" label="Automated Step" color="#534AB7" bg="#EEEDFE" />
      <FormField label="Title">
        <Input
          value={data.title}
          onChange={(e) => updateNodeData(id, { title: e.target.value })}
          placeholder="Step title"
        />
      </FormField>
      <FormField label="Action">
        <Select
          value={data.actionId}
          onChange={(e) =>
            updateNodeData(id, { actionId: e.target.value, actionParams: {} })
          }
          options={automations.map((a) => ({ value: a.id, label: a.label }))}
        />
        {currentAction && (
          <p className="text-xs text-gray-400 mt-1">{currentAction.description}</p>
        )}
      </FormField>
      {currentAction && currentAction.params.length > 0 && (
        <>
          <SectionTitle>Action parameters</SectionTitle>
          {currentAction.params.map((param) => (
            <FormField key={param} label={param}>
              <Input
                value={(data.actionParams ?? {})[param] ?? ''}
                onChange={(e) =>
                  updateNodeData(id, {
                    actionParams: {
                      ...(data.actionParams ?? {}),
                      [param]: e.target.value,
                    },
                  })
                }
                placeholder={param}
              />
            </FormField>
          ))}
        </>
      )}
      <DeleteButton onClick={() => deleteNode(id)} />
    </div>
  )
}

// ─── EndNodeForm ──────────────────────────────────────────────────────

export function EndNodeForm({ id }: { id: string }) {
  const node = useWorkflowStore((s) => s.nodes.find((n) => n.id === id))
  const updateNodeData = useWorkflowStore((s) => s.updateNodeData)
  const deleteNode = useWorkflowStore((s) => s.deleteNode)
  if (!node) return null
  const data = node.data as EndNodeData

  return (
    <div>
      <NodeFormHeader icon="■" label="End Node" color="#993C1D" bg="#FAECE7" />
      <FormField label="End message">
        <Input
          value={data.endMessage}
          onChange={(e) => updateNodeData(id, { endMessage: e.target.value })}
          placeholder="e.g. Onboarding complete"
        />
      </FormField>
      <div className="mt-4">
        <Toggle
          checked={data.summaryFlag}
          onChange={(val) => updateNodeData(id, { summaryFlag: val })}
          label="Generate summary report"
        />
      </div>
      <DeleteButton onClick={() => deleteNode(id)} />
    </div>
  )
}
