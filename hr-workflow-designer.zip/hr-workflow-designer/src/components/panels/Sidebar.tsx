import { NODE_TYPE_CONFIGS } from '../../lib/nodeConfig'
import { useNodeFactory } from '../../hooks'
import { useWorkflowStore } from '../../store/workflowStore'
import type { NodeType } from '../../types'

export function Sidebar() {
  const { createNode } = useNodeFactory()
  const nodes = useWorkflowStore((s) => s.nodes)

  const onDragStart = (e: React.DragEvent, type: NodeType) => {
    e.dataTransfer.setData('application/reactflow', type)
    e.dataTransfer.effectAllowed = 'move'
  }

  // Smart placement: offset from last node or default position
  const getAutoPosition = (_type: NodeType) => {
    if (nodes.length === 0) return { x: 200, y: 200 }
    const lastNode = nodes[nodes.length - 1]
    return { x: lastNode.position.x + 240, y: lastNode.position.y }
  }

  return (
    <div className="w-[220px] flex-shrink-0 bg-white border-r border-gray-100 flex flex-col h-full overflow-hidden">
      {/* Node palette */}
      <div className="px-3 pt-4 pb-2 border-b border-gray-100">
        <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1 px-1">
          Node types
        </p>
        <p className="text-[10px] text-gray-300 px-1">Drag onto canvas or click to add</p>
      </div>

      <div className="flex-1 overflow-y-auto px-3 py-3 flex flex-col gap-1.5">
        {Object.values(NODE_TYPE_CONFIGS).map((cfg) => (
          <div
            key={cfg.type}
            draggable
            onDragStart={(e) => onDragStart(e, cfg.type)}
            onClick={() => createNode(cfg.type, getAutoPosition(cfg.type))}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl border border-gray-100 cursor-pointer hover:border-gray-200 hover:shadow-sm transition-all active:scale-[0.98] group select-none"
          >
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center text-sm flex-shrink-0 transition-transform group-hover:scale-105"
              style={{ background: cfg.bgColor, color: cfg.color }}
            >
              {cfg.icon}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-gray-700">{cfg.label}</p>
              <p className="text-[10px] text-gray-400 truncate">{cfg.description}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Stats + tips */}
      <div className="px-4 py-4 border-t border-gray-50 flex-shrink-0">
        {nodes.length > 0 ? (
          <WorkflowStats />
        ) : (
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">Tips</p>
            <ul className="space-y-1.5 text-[10px] text-gray-400">
              <li>• Click node to place it</li>
              <li>• Or drag onto canvas</li>
              <li>• Drag ● handle to connect</li>
              <li>• Right-click for options</li>
              <li>• ⌘Z / ⌘Y undo/redo</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  )
}

function WorkflowStats() {
  const nodes = useWorkflowStore((s) => s.nodes)
  const edges = useWorkflowStore((s) => s.edges)

  const typeCounts = Object.values(NODE_TYPE_CONFIGS).map((cfg) => ({
    cfg,
    count: nodes.filter((n) => n.type === cfg.type).length,
  })).filter((x) => x.count > 0)

  return (
    <div>
      <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">Canvas</p>
      <div className="flex flex-col gap-1">
        {typeCounts.map(({ cfg, count }) => (
          <div key={cfg.type} className="flex items-center gap-2">
            <div className="w-4 h-4 rounded flex items-center justify-center text-[9px]"
              style={{ background: cfg.bgColor, color: cfg.color }}>
              {cfg.icon}
            </div>
            <span className="text-[11px] text-gray-500 flex-1">{cfg.label}</span>
            <span className="text-[10px] font-semibold text-gray-400">{count}</span>
          </div>
        ))}
        <div className="mt-1 pt-1 border-t border-gray-50 flex justify-between text-[10px] text-gray-400">
          <span>{edges.length} connection{edges.length !== 1 ? 's' : ''}</span>
          <span>{nodes.length} total</span>
        </div>
      </div>
    </div>
  )
}
