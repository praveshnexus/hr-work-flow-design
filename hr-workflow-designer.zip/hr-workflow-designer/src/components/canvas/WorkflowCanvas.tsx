import { useCallback, useRef, useState } from 'react'
import {
  Background,
  BackgroundVariant,
  Controls,
  MiniMap,
  ReactFlow,
  type ReactFlowInstance,
  type Node,
  type Edge,
  type NodeMouseHandler,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import { useWorkflowStore } from '../../store/workflowStore'
import { nodeTypes } from '../nodes'
import { useNodeFactory, useWorkflowExport, useKeyboardShortcuts } from '../../hooks'
import type { NodeType } from '../../types'
import { NodeContextMenu } from './ContextMenu'

interface CtxMenu { nodeId: string; x: number; y: number }

export function WorkflowCanvas() {
  const nodes = useWorkflowStore((s) => s.nodes) as Node[]
  const edges = useWorkflowStore((s) => s.edges) as Edge[]
  const onNodesChange = useWorkflowStore((s) => s.onNodesChange)
  const onEdgesChange = useWorkflowStore((s) => s.onEdgesChange)
  const onConnect = useWorkflowStore((s) => s.onConnect)
  const selectNode = useWorkflowStore((s) => s.selectNode)
  const { createNode } = useNodeFactory()
  const rfRef = useRef<ReactFlowInstance | null>(null)
  const [ctxMenu, setCtxMenu] = useState<CtxMenu | null>(null)

  useKeyboardShortcuts()

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      const type = e.dataTransfer.getData('application/reactflow') as NodeType
      if (!type || !rfRef.current) return
      const position = rfRef.current.screenToFlowPosition({ x: e.clientX, y: e.clientY })
      createNode(type, position)
    },
    [createNode]
  )

  const onNodeContextMenu: NodeMouseHandler = useCallback((e, node) => {
    e.preventDefault()
    setCtxMenu({ nodeId: node.id, x: e.clientX, y: e.clientY })
  }, [])

  const handleDuplicate = useCallback((id: string) => {
    const store = useWorkflowStore.getState()
    const node = store.nodes.find((n) => n.id === id)
    if (!node) return
    createNode(node.type as NodeType, { x: node.position.x + 40, y: node.position.y + 40 })
    // Copy data after creation
    setTimeout(() => {
      const newNodes = useWorkflowStore.getState().nodes
      const newest = newNodes[newNodes.length - 1]
      if (newest) store.updateNodeData(newest.id, { ...node.data })
    }, 10)
  }, [createNode])

  return (
    <div className="flex-1 h-full flex flex-col overflow-hidden">
      <Toolbar createNode={createNode} rfRef={rfRef} />
      <div className="flex-1 relative">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          nodeTypes={nodeTypes}
          onInit={(inst) => { rfRef.current = inst as ReactFlowInstance }}
          onDrop={onDrop}
          onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move' }}
          onPaneClick={() => { selectNode(null); setCtxMenu(null) }}
          onNodeContextMenu={onNodeContextMenu}
          fitView
          fitViewOptions={{ padding: 0.25 }}
          defaultEdgeOptions={{
            style: { stroke: '#94a3b8', strokeWidth: 1.5 },
            animated: false,
          }}
          deleteKeyCode={null} // handled manually in useKeyboardShortcuts
          proOptions={{ hideAttribution: true }}
          className="bg-slate-50"
        >
          <Background variant={BackgroundVariant.Dots} gap={20} size={1} color="#cbd5e1" />
          <Controls
            className="!shadow-none !border !border-gray-200 !rounded-xl !bg-white"
            showInteractive={false}
          />
          <MiniMap
            nodeColor={(n) => (
              { start: '#dbeafe', task: '#dcfce7', approval: '#fef3c7', automated: '#ede9fe', end: '#fee2e2' }
              [n.type ?? ''] ?? '#f1f5f9'
            )}
            maskColor="rgba(248,250,252,0.85)"
            className="!shadow-none !border !border-gray-200 !rounded-xl !bg-white"
          />

          {nodes.length === 0 && <EmptyState />}
        </ReactFlow>

        {ctxMenu && (
          <NodeContextMenu
            nodeId={ctxMenu.nodeId}
            x={ctxMenu.x}
            y={ctxMenu.y}
            onClose={() => setCtxMenu(null)}
            onDuplicate={handleDuplicate}
          />
        )}
      </div>
    </div>
  )
}

// ─── Empty state overlay ─────────────────────────────────────────────
function EmptyState() {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 pointer-events-none" style={{ zIndex: 4 }}>
      <div className="w-16 h-16 rounded-2xl bg-white border-2 border-dashed border-gray-200 flex items-center justify-center text-3xl">
        ✦
      </div>
      <div className="text-center">
        <p className="text-sm font-medium text-gray-500">Drag nodes from the sidebar</p>
        <p className="text-xs text-gray-400 mt-1">or click any node type to auto-place it</p>
      </div>
      <div className="flex gap-3 text-xs text-gray-300 mt-2">
        <span>⌘Z undo</span>
        <span>·</span>
        <span>⌘Y redo</span>
        <span>·</span>
        <span>Del remove</span>
        <span>·</span>
        <span>Right-click menu</span>
      </div>
    </div>
  )
}

// ─── Toolbar ──────────────────────────────────────────────────────────
function Toolbar({
  createNode,
  rfRef,
}: {
  createNode: (type: NodeType, pos: { x: number; y: number }) => string
  rfRef: React.RefObject<ReactFlowInstance | null>
}) {
  const clearWorkflow = useWorkflowStore((s) => s.clearWorkflow)
  const undo = useWorkflowStore((s) => s.undo)
  const redo = useWorkflowStore((s) => s.redo)
  const past = useWorkflowStore((s) => s.past)
  const future = useWorkflowStore((s) => s.future)
  const nodes = useWorkflowStore((s) => s.nodes)
  const edges = useWorkflowStore((s) => s.edges)
  const { exportWorkflow, importWorkflow } = useWorkflowExport()
  const fileInputRef = useRef<HTMLInputElement>(null)

  const loadDemo = () => {
    clearWorkflow()
    setTimeout(() => {
      const store = useWorkflowStore.getState()
      const n1 = createNode('start',     { x: 80,  y: 180 })
      const n2 = createNode('task',      { x: 320, y: 80  })
      const n3 = createNode('approval',  { x: 570, y: 80  })
      const n4 = createNode('automated', { x: 570, y: 280 })
      const n5 = createNode('end',       { x: 820, y: 180 })
      store.updateNodeData(n1, { title: 'Onboarding Start', metadata: [{ id: '1', key: 'department', value: 'Engineering' }] })
      store.updateNodeData(n2, { title: 'Collect Documents', assignee: 'HR Admin', description: 'Collect ID, degree cert, bank details' })
      store.updateNodeData(n3, { title: 'Manager Approval', approverRole: 'Manager', autoApproveThreshold: 3 })
      store.updateNodeData(n4, { title: 'Send Welcome Email', actionId: 'send_email', actionParams: { to: 'new.hire@company.com', subject: 'Welcome aboard!', body: 'Excited to have you.' } })
      store.updateNodeData(n5, { title: 'Onboarding Complete', endMessage: 'Employee successfully onboarded', summaryFlag: true })
      ;([[n1,n2],[n2,n3],[n3,n5],[n2,n4],[n4,n5]] as [string,string][]).forEach(([s,t]) => {
        store.onConnect({ source: s, target: t, sourceHandle: null, targetHandle: null })
      })
      setTimeout(() => rfRef.current?.fitView({ padding: 0.25 }), 100)
    }, 50)
  }

  return (
    <div className="flex items-center gap-2 px-4 py-2.5 bg-white border-b border-gray-100 flex-shrink-0">
      {/* Logo */}
      <div className="flex items-center gap-2 mr-3">
        <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white text-[9px] font-bold tracking-tight">HR</div>
        <span className="text-sm font-semibold text-gray-700 hidden sm:block">Workflow Designer</span>
      </div>

      <div className="h-4 w-px bg-gray-100" />

      {/* Undo / Redo */}
      <div className="flex gap-1">
        <ToolbarBtn onClick={undo} disabled={past.length === 0} title="Undo (⌘Z)">↩ Undo</ToolbarBtn>
        <ToolbarBtn onClick={redo} disabled={future.length === 0} title="Redo (⌘Y)">↪ Redo</ToolbarBtn>
      </div>

      <div className="h-4 w-px bg-gray-100" />

      {/* Actions */}
      <ToolbarBtn onClick={loadDemo}>Load demo</ToolbarBtn>
      <ToolbarBtn onClick={exportWorkflow} disabled={nodes.length === 0}>Export JSON</ToolbarBtn>
      <ToolbarBtn onClick={() => fileInputRef.current?.click()}>Import JSON</ToolbarBtn>
      <input
        ref={fileInputRef}
        type="file"
        accept=".json"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0]
          if (file) { importWorkflow(file); e.target.value = '' }
        }}
      />
      <ToolbarBtn
        onClick={() => { if (confirm('Clear the entire canvas?')) clearWorkflow() }}
        disabled={nodes.length === 0}
        danger
      >
        Clear
      </ToolbarBtn>

      {/* Stats */}
      <div className="ml-auto flex items-center gap-3 text-xs text-gray-400">
        {past.length > 0 && (
          <span className="text-gray-300">{past.length} action{past.length !== 1 ? 's' : ''}</span>
        )}
        <span>{nodes.length} node{nodes.length !== 1 ? 's' : ''}</span>
        <span>·</span>
        <span>{edges.length} edge{edges.length !== 1 ? 's' : ''}</span>
      </div>
    </div>
  )
}

function ToolbarBtn({
  onClick, children, danger, disabled, title,
}: {
  onClick: () => void
  children: React.ReactNode
  danger?: boolean
  disabled?: boolean
  title?: string
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors border ${
        disabled
          ? 'border-transparent text-gray-300 cursor-not-allowed'
          : danger
          ? 'border-red-100 text-red-400 hover:bg-red-50 hover:text-red-600'
          : 'border-gray-100 text-gray-500 hover:bg-gray-50 hover:text-gray-800'
      }`}
    >
      {children}
    </button>
  )
}
