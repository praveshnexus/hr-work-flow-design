import { useEffect, useRef } from 'react'
import { useWorkflowStore } from '../../store/workflowStore'
import { getNodeConfig } from '../../lib/nodeConfig'
import type { NodeType } from '../../types'

interface ContextMenuProps {
  nodeId: string
  x: number
  y: number
  onClose: () => void
  onDuplicate: (id: string) => void
}

export function NodeContextMenu({ nodeId, x, y, onClose, onDuplicate }: ContextMenuProps) {
  const ref = useRef<HTMLDivElement>(null)
  const deleteNode = useWorkflowStore((s) => s.deleteNode)
  const nodes = useWorkflowStore((s) => s.nodes)
  const node = nodes.find((n) => n.id === nodeId)

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose()
    }
    window.addEventListener('mousedown', handler)
    return () => window.removeEventListener('mousedown', handler)
  }, [onClose])

  if (!node) return null
  const cfg = getNodeConfig(node.type as NodeType)

  const items = [
    {
      label: 'Duplicate node',
      icon: '⎘',
      action: () => { onDuplicate(nodeId); onClose() },
    },
    {
      label: 'Delete node',
      icon: '✕',
      danger: true,
      action: () => { deleteNode(nodeId); onClose() },
    },
  ]

  return (
    <div
      ref={ref}
      className="fixed z-50 bg-white border border-gray-200 rounded-xl shadow-xl py-1.5 min-w-[160px]"
      style={{ left: x, top: y }}
    >
      {/* Node label */}
      <div className="px-3 py-2 border-b border-gray-100 flex items-center gap-2 mb-1">
        <span className="text-sm" style={{ color: cfg.color }}>{cfg.icon}</span>
        <span className="text-xs font-semibold text-gray-600 truncate">{node.data.title || cfg.label}</span>
      </div>

      {items.map((item) => (
        <button
          key={item.label}
          onClick={item.action}
          className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs transition-colors text-left ${
            item.danger
              ? 'text-red-500 hover:bg-red-50'
              : 'text-gray-600 hover:bg-gray-50'
          }`}
        >
          <span className="text-sm w-4 text-center">{item.icon}</span>
          {item.label}
        </button>
      ))}
    </div>
  )
}
