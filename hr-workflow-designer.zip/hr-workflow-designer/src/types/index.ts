// ─── Node Data Types ───────────────────────────────────────────────
export type NodeType = 'start' | 'task' | 'approval' | 'automated' | 'end'

export interface KVPair {
  id: string
  key: string
  value: string
}

// React Flow requires data to extend Record<string, unknown>
export interface StartNodeData extends Record<string, unknown> {
  nodeType: 'start'
  title: string
  metadata: KVPair[]
}

export interface TaskNodeData extends Record<string, unknown> {
  nodeType: 'task'
  title: string
  description: string
  assignee: string
  dueDate: string
  customFields: KVPair[]
}

export interface ApprovalNodeData extends Record<string, unknown> {
  nodeType: 'approval'
  title: string
  approverRole: string
  autoApproveThreshold: number
}

export interface AutomatedNodeData extends Record<string, unknown> {
  nodeType: 'automated'
  title: string
  actionId: string
  actionParams: Record<string, string>
}

export interface EndNodeData extends Record<string, unknown> {
  nodeType: 'end'
  title: string
  endMessage: string
  summaryFlag: boolean
}

export type WorkflowNodeData =
  | StartNodeData
  | TaskNodeData
  | ApprovalNodeData
  | AutomatedNodeData
  | EndNodeData

// ─── API Types ─────────────────────────────────────────────────────
export interface AutomationAction {
  id: string
  label: string
  params: string[]
  description: string
}

export interface SimulateRequest {
  nodes: SerializedNode[]
  edges: SerializedEdge[]
}

export interface SimulateStepResult {
  nodeId: string
  nodeType: NodeType
  title: string
  status: 'success' | 'pending' | 'skipped' | 'error'
  detail: string
  timestamp: string
  durationMs: number
}

export interface SimulateResponse {
  success: boolean
  steps: SimulateStepResult[]
  errors: string[]
  totalDurationMs: number
}

// ─── Serialized workflow ────────────────────────────────────────────
export interface SerializedNode {
  id: string
  type: NodeType
  position: { x: number; y: number }
  data: WorkflowNodeData
}

export interface SerializedEdge {
  id: string
  source: string
  target: string
}

export interface WorkflowExport {
  version: string
  name: string
  exportedAt: string
  nodes: SerializedNode[]
  edges: SerializedEdge[]
}

// ─── Validation ─────────────────────────────────────────────────────
export interface ValidationError {
  nodeId?: string
  message: string
  severity: 'error' | 'warning'
}
