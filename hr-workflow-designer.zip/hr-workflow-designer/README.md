# HR Workflow Designer

A visual drag-and-drop workflow builder for HR admins. Built for the Tredence Studio AI Engineering internship case study.

## Quick Start

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build
```

## Features

- **Visual canvas** — drag-and-drop nodes, connect with edges, pan/zoom/minimap
- **5 node types** — Start, Task, Approval, Automated Step, End
- **Node edit forms** — click any node to configure it in the right panel
- **Mock API layer** — `GET /automations` + `POST /simulate` (local mocks with realistic delays)
- **Workflow sandbox** — validates graph structure and runs step-by-step simulation
- **Export JSON** — download the full workflow as `workflow.json`
- **Demo workflow** — "Load demo" seeds a pre-built HR onboarding flow

## Architecture

```
src/
├── types/index.ts          # All TypeScript interfaces (NodeData, API, Validation)
├── api/mockApi.ts          # GET /automations, POST /simulate — local mocks
├── store/workflowStore.ts  # Zustand store — nodes, edges, selectedNodeId, actions
├── hooks/index.ts          # useNodeFactory, useWorkflowValidation, useSimulation, useWorkflowExport
├── lib/
│   ├── nodeConfig.ts       # Node type metadata — colors, icons, labels
│   └── nanoid.ts           # Tiny ID generator
└── components/
    ├── nodes/
    │   ├── BaseNode.tsx     # Shared node shell (badge, title, subtitle, handles)
    │   └── index.tsx        # 5 typed node components + nodeTypes map
    ├── panels/
    │   ├── Sidebar.tsx      # Draggable node palette
    │   ├── RightPanel.tsx   # Edit / Sandbox tab container
    │   └── NodeForms.tsx    # Per-node-type configuration forms
    ├── canvas/
    │   └── WorkflowCanvas.tsx  # React Flow wrapper, drop handler, toolbar
    └── ui/index.tsx         # Input, Select, Textarea, Toggle, KVEditor, etc.
```

## Design Decisions

**Zustand over Redux/Context** — flat store with selector subscriptions, minimal boilerplate, easy to extend.

**React Flow as controlled component** — nodes/edges live in Zustand, passed as controlled props. Base `Node[]` cast bridges the generic variance gap between our typed store and React Flow's API.

**Discriminated union node data** — each node type has its own interface with a `nodeType` discriminant field, enabling exhaustive type switching in forms while satisfying React Flow's `Record<string, unknown>` constraint via `extends`.

**Isolated API layer** — `mockApi.ts` can be swapped for real HTTP calls without touching any component. Simulated `delay()` gives realistic async behaviour in development.

**Per-type form components** — each node type gets a dedicated form in `NodeForms.tsx`. Dynamic action parameters in `AutomatedNodeForm` are driven by the mock API response.

## What I'd Add With More Time

- Undo/redo via Zustand middleware
- Import workflow from JSON
- Visual validation errors shown on nodes (red rings)
- Conditional edge labels / branching logic
- Auto-layout with Dagre
- Node version history
- Real FastAPI backend with PostgreSQL persistence
